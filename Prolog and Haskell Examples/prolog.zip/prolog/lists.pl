:- set_prolog_flag( singleton_warning, off ).

%
% concat( Xs, Ys, Zs ) if Zs is the concatenation of lists Xs and Ys
%
concat( [X|Xs], Ys, [X|Zs] ) :- concat( Xs, Ys, Zs ).
concat( [], Ys, Ys ).


%
% rev( Xs, Xs' ) if Xs' is the reversal of list Xs.
%
rev( [], [] ).
rev( [U|Xs], Ys ) :-
   rev( Xs, Zs ), concat( Zs, [U], Ys ).


%
% amember( X, Ys ) if X is a member of list Ys
%
amember( X, [X|Xs] ).
amember( X, [_|Ys] ) :- amember( X, Ys ).


%
% len( L, N ) if N is the length of list L
%
len( [], 0 ).
len( [X|Xs], N ) :- len( Xs, N1 ), N is N1 + 1.


%
% len1( L, N ) is true if the length of list L is N
%
len1( L, N ) :-
   len( L, N, 0 ).

%
% len( L, N, M ) is true if N-M is the length of list L
%
len( [], N, N ).
len( [_|L], N1, N2 ) :-
    N3 is N2+1,
    len( L, N1, N3 ).


%
% aprefix( P, L ) holds if P is a prefix of list L
%
aprefix( P, L ) :- concat( P, S, L ).

%
% asuffix( S, L ) holds if P is a suffix of list L
%
asuffix( S, L ) :- concat( P, S, L ).


%
% member1( X, Ys ) if X is a member of list Ys
%
member1( X, L ) :- concat( _, [X|_], L ).


%
% sublist( S, L ) if S is a sublist of L
%
asublist( B, ABC ) :- 
	concat( AB, C, ABC ), 
	concat( A, B, AB ).

%
% remove( X, L, D ) if D is the list after removing X from L
%
remove( X, L, D ) :-
    	concat( P, [X|S], L ), 
	concat( P, S, D ).


%
% perm( L, P ) holds if P is a permutation of list L
%
perm( [], [] ).
perm( Xs, [X|Ys] ) :- 
    	remove( X, Xs, Xs1 ), 
	perm( Xs1, Ys ). 


%
% ordered( L ) holds if the elements of L are in ascending order
%
ordered( [] ).
ordered( [_] ).
ordered( [X,Y|Ys] ) :- X =< Y, ordered( [Y|Ys] ).


%
% dsort( L, M ) holds if M is in ascending order of list L
%
dsort( L, M ) :- perm( L, M ), ordered( M ).


%
% last( X, L ) holds if X is the last element of list L
%
last(X,L) :- concat( P, [X],L ).

