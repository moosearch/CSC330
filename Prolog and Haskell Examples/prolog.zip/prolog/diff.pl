:- set_prolog_flag( singleton_warning, off ).

%
% diff( X, L ) is true if X is different from all elements of L
%

diff( X, [] ).
diff( X, [Y|Ys] ) :- X \= Y, diff( X, Ys ).

%
% alldiff( L ) is true if all elements of L are different
%
alldiff( [] ).
alldiff( [X] ).
alldiff( [X1,X2|Xs] ) :- X1 \= X2, alldiff( [X1|Xs] ), alldiff( [X2|Xs] ).
