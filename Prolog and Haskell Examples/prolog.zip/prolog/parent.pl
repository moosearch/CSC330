:- public( father/2, mother/2, parent/2, ancestor/2, sibling/2 ).
:- public( male/1, female/1, son/2, daughter/2, cousin/2 ).

%
% parent(X,Y) is true if X is a parent of Y
%
parent(X,Y) :- mother(X,Y).
parent(X,Y) :- father(X,Y).

mother(jane,bob).
mother(lucy,john).
mother(mary,david).
mother(lucy,mary).

father(bob,eric).
father(bill,john).
father(mike,mary).

ancestor(X,Z) :- parent(X,Y), parent(Y,Z).
ancestor(X,Z) :- parent(X,Y), ancestor(Y,Z).

male(bob).
male(john).
male(david).
male(eric).
male(bill).
male(mike).

female(mary).
female(lucy).
female(jane).

son(X,Y) :- parent(Y,X), male(X).
daugther(X,Y) :- parent(Y,X), female(X).
sibling(X,Y) :- parent(Z,X), parent(Z,Y), X \= Y.
cousin(X,Y) :- parent(U,X), parent(V,Y), sibling(U,V).
