
%
% and(X,Y,Z) is true if Z is the boolean AND of X and Y.
%
and(0,0,0).
and(0,1,0).
and(1,0,0).
and(1,1,1).

%
% or(X,Y,Z) is true if Z is the boolean OR of X and Y.
%
or(0,0,0).
or(0,1,1).
or(1,0,1).
or(1,1,1).

%
% invert(X,Y) is true if X is the boolean inverter of Y
%
invert(0,1).
invert(1,0).

%
% nand(X,Y,Z) is true if Z is the boolean NAND of X and Y.
%
nand(X,Y,Z) :- and(X,Y,W), invert(W,Z).

%
% nor(X,Y,Z) is true if Z is the boolean NOR of X and Y.
%
nor(X,Y,Z) :- or(X,Y,W), invert(W,Z).

%
% xor(X,Y,Z) is true if Z is the boolean EXCLUSIVE-OR of X and Y.
%
xor(X,Y,Z) :- 
    invert(X,NX), invert(Y,NY), and(Y,NX,Z1), and(X,NY,Z2), or(Z1,Z2,Z).

%
% ha(X,Y,C,S) is true if S is the sum of X and Y and C is the carry
%
ha(X,Y,C,S) :- xor(X,Y,S), and(X,Y,C).

%
% fa(X,Y,Z,C,S) is true if S is the sum of X,Y and Z where Z is the previous
%	carry and C is the new carry.
%
fa(A,B,Cin,Cout,S) :-
    ha(A,B,C1,S1), ha(Cin,S1,C2,S), or(C1,C2,Cout).

%
% f2a(X1,Y1,X2,Y2,Z,C,S0,S1) is true if S0 and S1 are the two bit sum of 
%    X1,Y1,X2,Y2 and Z where Z is the previous carry, and C is the new carry.
%
f2a(A0,B0,A1,B0,C0,Cout,S0,S1) :-
    fa(A0,B0,C0,C1,S0),
    fa(A1,B1,C1,Cout,S1).
