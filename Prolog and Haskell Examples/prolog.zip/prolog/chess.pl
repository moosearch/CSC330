:- include(diff).
:- include(len).

%
% move1( (X1,Y1), (X2,Y2) ) holds if a Knight can move in one step from 
% (X1,Y1) to (X2,Y2) on a 8x8 chess board
%
move1( (X1,Y1), (X2,Y2) ) :- right1( X1, X2 ), up2( Y1, Y2 ).
move1( (X1,Y1), (X2,Y2) ) :- right2( X1, X2 ), up1( Y1, Y2 ).
move1( (X1,Y1), (X2,Y2) ) :- right1( X1, X2 ), down2( Y1, Y2 ).
move1( (X1,Y1), (X2,Y2) ) :- right2( X1, X2 ), down1( Y1, Y2 ).

move1( (X1,Y1), (X2,Y2) ) :- left1( X1, X2 ), up2( Y1, Y2 ).
move1( (X1,Y1), (X2,Y2) ) :- left2( X1, X2 ), up1( Y1, Y2 ).
move1( (X1,Y1), (X2,Y2) ) :- left1( X1, X2 ), down2( Y1, Y2 ).
move1( (X1,Y1), (X2,Y2) ) :- left2( X1, X2 ), down1( Y1, Y2 ).

right1( U, V ) :- next_x( U, V ).
right2( U, W ) :- next_x( U, V ), next_x( V, W ).
left1( U, V ) :- right1( V, U ).
left2( U, V ) :- right2( V, U ).
up1( U, V ) :- next_y( U, V ).
up2( U, W ) :- next_y( U, V ), next_y( V, W ).
down1( U, V ) :- up1( V, U ).
down2( U, V ) :- up2( V, U ).

next_y( 1, 2 ).
next_y( 2, 3 ).
next_y( 3, 4 ).
next_y( 4, 5 ).
% next_y( 5, 6 ).
% next_y( 6, 7 ).
% next_y( 7, 8 ).

next_x( a, b ).
next_x( b, c ).
next_x( c, d ).
next_x( d, e ).
% next_x( e, f ).
% next_x( f, g ).
% next_x( g, h ).

%
% path( P1, P2 ) holds if there exists a sequence of Knight's moves from 
%	position P1 to P2.
%
path( P1, P2 ) :- move1( P1, P2 ).
path( P1, P3 ) :- move1( P1, P2 ), path( P2, P3 ).


%
% apath( P1, P2, T ) holds if there exists a sequence T of Knight's moves from 
%	position P1 to P2.
%
apath( P1, P2, [P1,P2] ) :- 
	move1( P1, P2 ).
apath( P1, P3, [P1|T] )  :- 
	apath( P2, P3, T ),
	move1( P1, P2 ), 
	diff( P1, T ).


%
% tour( S, T ) holds if T is a tour of every square on the chess board by
%	a Knight starting at postion S
%
tour( S, T ) :-
	len( T, 25 ),  % a 5x5 board
	apath( S, _, T ).


