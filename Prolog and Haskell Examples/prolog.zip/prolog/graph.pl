%
% edge(X,Y) if there is a directed edge from vertex X to vertex Y
%
edge(a,b).
edge(a,c).
edge(b,d).
edge(d,e).
edge(e,a).
edge(c,f).
edge(f,g).
edge(f,e).

%
% path(X,Y) is true if there exist a directed path from vertex X to Y
%
path(X,Y) :- edge(X,Y).
path(X,Z) :- edge(X,Y), path(Y,Z).

%
% path1(X,Y) is true if there exist a directed path from vertex X to Y
%
path1(X,Y) :- edge(X,Y).
path1(X,Z) :- path1(Y,Z), edge(X,Y).

%
% path2(X,Y) is true if there exist a directed path from vertex X to Y
%
path2(X,Y) :- edge(X,Y).
path2(X,Z) :- edge(Y,Z), path(X,Y).
