%
% qsort( L, S ) holds if S is the (quick) sorted list of L
%
qsort( [], [] ).
qsort( [U|Xs], Ys ) :-
    partition( U, Xs, XLs, XHs ),
    qsort( XHs, Hs ),
    qsort( XLs, Ls ),
    concat( Ls, [U|Hs], Ys ).

%
% partition( X, U, L, H ) holds if L constains all elements "lower" than
%	X in list U, and H contains all "higher" elements than X in U.
%
partition( U, [], [], [] ).
partition( U, [V|Vs], [V|Ls], Hs ) :-
    V =< U, partition( U, Vs, Ls, Hs ).
partition( U, [V|Vs], Ls, [V|Hs] ) :-
    V > U, partition( U, Vs, Ls, Hs ).


%
% isort( L, S ) holds if S is the (insertion) sorted list of L
%
isort([],[]).
isort([X|Xs],Ys) :- 
	isort(Xs,Zs), 
	insert(X,Zs,Ys).


%
% insert( X, U, L ) holds if L is the new list after inserting X into
%	U while maintaining L in ascending order.
%
insert(X,[],[X]).
insert(X,[Y|Ys],[Y|Zs]) :- 
	X > Y, insert(X,Ys,Zs).
insert(X,[Y|Ys],[X,Y|Ys]) :- 
	X =< Y.


