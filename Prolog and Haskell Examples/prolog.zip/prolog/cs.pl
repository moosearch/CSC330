:- set_prolog_flag(unknown,fail).

%
% inference rules
%
csmajor :- csreq, mathreq, english, electives.

csreq :- csc1, csc2, csc3, csc4.

csc1 :- csc110, csc115, csc212.
csc2 :- csc230, csc225, seng265.
csc3 :- csc320, csc330, csc355, csc360, csc370, seng321.
csc4 :- csc450, csc454.
csc4 :- csc450, csc460.


mathreq :- math1, math2, math3.
math1 :- math100, math101, math122.
math2 :- math200, math201, math222, math233a.
math2 :- math202, math233c, math222, math233a.
math3 :- stat260.

english :- engl115, engl240.
english :- engl135, engl240.

electives :- elective1, elective2, elective3, elective4.
elective1 :- econ101.
elective2 :- basketweaving101.
elective3 :- music101.
elective4 :- dancing101.


%
% Jane Doe
%
csc110.
csc115.
csc212.
csc230.
csc225.
csc320.
csc330.
csc355.
csc360.
csc365.
csc370.

math100.
math101.
math122.
math200.
math201.
math222.
math233a.
stat260.

engl115.
engl240.

seng265.
seng321.

econ101.
music101.
dancing101.