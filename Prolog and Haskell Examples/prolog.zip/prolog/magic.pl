:- include( diff ).


% A magic square of 3X3 with numbers range from 1 to 9:
%
%   X7, X8, X9
%	X4, X5, X6
%	X1, X2, X3
%

magic( X1, X2, X3, X4, X5, X6, X7, X8, X9 ) :-
	digit(X1), digit(X2), digit(X3), alldiff( [X1,X2,X3] ),
	S is X1+X2+X3,   	% rows
	digit(X4), digit(X5), digit(X6), alldiff( [X1,X2,X3,X4,X5,X6] ),
	S is X4+X5+X6,		% rows
	digit(X7), digit(X8), digit(X9),
	alldiff( [X1,X2,X3,X4,X5,X6,X7,X8,X9] ),
	S is X7+X8+X9,		% rows
	S is X1+X4+X7,		% columns
	S is X2+X5+X8,
	S is X3+X6+X9,
	S is X1+X5+X9,		% diagonals
	S is X3+X5+X7.


digit(1).
digit(2).
digit(3).
digit(4).
digit(5).
digit(6).
digit(7).
digit(8).
digit(9).
