%
% This is a GNU Prolog's flag, which sets upon an "unknown" (or undefined)
% predicate, assume it is false.
%
:- set_prolog_flag(unknown,fail).

%
% inference rules
%

%
% csmajor(X) if true if student X has met his/her CS major degree requirements,
%
csmajor(X) :- csreq(X), mathreq(X), english(X), electives(X).

csreq(X) :- csc1(X), csc2(X), csc3(X), csc4(X).

csc1(Y) :- csc110(Y), csc115(Y), csc212(Y).
csc2(X) :- csc230(X), csc225(X), seng265(X).
csc3(X) :- csc320(X), csc330(X), csc355(X), csc360(X), csc370(X), seng321(X).
csc4(X) :- csc450(X), csc454(X).
csc4(X) :- csc450(X), csc460(X).


mathreq(X) :- math1(X), math2(X), math3(X).
math1(X) :- math100(X), math101(X), math122(X).
math2(X) :- math200(X), math201(X), math222(X), math233a(X).
math2(X) :- math202(X), math233c(X), math222(X), math233a(X).
math3(X) :- stat260(X).

english(X) :- engl115(X), engl240(X).
english(X) :- engl135(X), engl240(X).

electives(X) :- elective1(X), elective2(X), elective3(X), elective4(X).
elective1(X) :- econ101(X).
elective2(X) :- basketweaving101(X).
elective3(X) :- music101(X).
elective4(X) :- dancing101(X).


%
% Jane Doe and John Doe
%
csc110(jane).         csc110(john).
csc115(jane).         csc115(john).
csc212(jane).         csc212(john).
csc230(jane).

csc225(jane).
csc320(jane).
csc330(jane).
csc355(jane).
csc360(jane).
csc365(jane).
csc370(jane).

math100(jane).
math101(jane).
math122(jane).
math200(jane).
math201(jane).
math222(jane).
math233a(jane).
stat260(jane).

engl115(jane).
engl240(jane).

seng265(jane).
seng321(jane).

econ101(jane).
music101(jane).
dancing101(jane).
