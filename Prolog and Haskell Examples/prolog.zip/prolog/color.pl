%
% We try to color the following map:
%
%     +------------------------+
%     |           A            |
%     +-----------+------------+
%     |    B      |     C      |
%     +-----------+------------+
%     |           D            |
%     +------------------------+
%
% map( A, B, C, D ) is true if there exists a color assignment so that
%    no adjacent countries have the same color, i.e., A and B, A and C
%    B and C, B and D, finally C and D, all have different colors.
%
%  We may choose to use 3 colors or 4 colors.
%
map( A, B, C, D ) :-
  color( A ), color( B ), color( C ), color( D ),
  A \= B, A \= C, B \= C, D \= B, D \= C.

color( red ).
color( blue ).
color( green ).
%color( yellow ).
