:- include( diff ).

%
% member( X, S ) holds if X is a member of list S
%
% member( X, [X|_] ).
% member( X, [_|L] ) :- member( X, L ).



%
% intersect( S1, S2 ) holds if sets S1 and S2 have a non-empty intersection
%
intersect( S1, S2 ) :-
	member( X, S1 ),
	member( X, S2 ).


%
% subset( S1, S2 ) holds if set S1 is a subset of the set S2
%
subset( [], _ ).
subset( [X|T], S ) :- 
	subset( T, S ),
	member( X, S ).


%
% remove( X, S1, S2 ) holds if S2 is the result of removing element X from S1
%
%  Assume that X is a member of S1.
%
%remove( X, [], [] ).
remove( X, [X|S], S ).
remove( X, [Y|S], [Y|S1] ) :- remove( X, S, S1 ).


subset1( [], _ ).
subset1( [X|S], S1 ) :-
	remove( X, S1, S2 ),
	subset1( S, S2 ).


%
% intersection( S1, S2, S ) holds if S is a non-empty intersection of 
% 	sets S1 and S2
%
intersection( [], _, [] ).
intersection( [X|T], S, [X|T1] ) :-
	intersection( T, S, T1 ),
	member( X, S ), 
	diff( X, T1 ).
intersection( [X|T], S, T1 ) :-
	intersection( T, S, T1 ),
	diff( X, S ).


intersection1( [], _, [] ).
intersection1( [X|S1], S2, [X|S] ) :-
	remove( X, S2, T1 ),
	intersection1( S1, T1, S ).
intersection1( [X|S1], S2, S ) :-
	diff( X, S2 ),
	intersection1( S1, S2, S ).


intersection2( S1, S2, [X|S] ) :-
	subset1( [X|S], S1 ),
	subset1( [X|S], S2 ).
