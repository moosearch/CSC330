--
-- Due to strong typing, we cannot express a non-recursive "fixed point"
-- combinator in Haskell, such as:
--   Y = \f -> ((\x -> f (x x)) (\x -> f (x x)))
-- such that for all functions F, (Y F) = F(Y F).
--
-- The following is an approximation of a "fixed point" combinator.
--   
fix f = f (fix f)

--
-- A partial non-recursive definition of a "factorial" function.
-- (Note: "fac" does not appear on the RHS. Hence, it is non-recursive.)
--
fac = \f -> \n -> if n == 0 then 1 else n * f(n-1)

--
-- Now try:
--
-- fix fac
-- (fix fac) 5
-- fac (fix fac) 5
--
-- Note: (fix fac) is the "actual" recursive "fac" function because
--    (fix fac) = fac( fix fac ) = fac( fac (fix fac))
--    fac( fac( ... fac( fix fac ) ...))
--
-- We can use "Y" instead of "fix". There are infinite many fixed point
-- combinators.
--
