--
-- membership function
--
mem e l = if (l == []) then False
          else if (e == (head l)) then True
          else mem e (tail l)

--
-- Try:
--       mem 1 []
--       mem 5 [1..10]
--       mem 11 [1..10]
--

--
-- appending lists
--
append l1 l2 = if l1 == [] then l2
               else (head l1) : (append (tail l1) l2)

--
-- an infinite list of integers starting from "n"
--
ints n = n : (ints (n+1))


--
-- a finite prefix "n" of list "l"
--
prefix n l = if n == 0 then []
             else if not (null l) then (head l) : (prefix (n-1) (tail l))
                                  else []

--
-- Try:
--      ints 0
--      prefix 10 (ints 0)
--      prefix 100 (ints 0)
