-- Encoding Church's numerals
-- 0 = \f -> \x -> x
-- 1 = \f -> \x -> f x
-- 2 = \f -> \x -> f (f x)
-- 3 = \f -> \x -> f (f (f x))
-- ...
--                  n
-- n = \f -> \x -> f x
--
church 0 = \f -> \x -> x
church 1 = \f -> \x -> f x
church n = \f -> \x -> f (church (n-1)) f x)

--
-- (+1) is the function \x -> x + 1
--
unchurch n = n (+1) 0

-- For the following functions, we
-- assume all "m" and "n" are Church's numerals
--
plus m n = \f -> \x -> m f (n f x)

succ n = \f -> \x -> f (n f x)

mult m n = \f -> \x -> n (m f) x

exp m n = n m

true = \x -> \y -> x

false = \x -> \y -> y

iszero n = n (\x -> false) true


