true = \x-> \y-> x
false = \x-> \y-> y

zero = \f-> \x-> x
one  = \f-> \x-> f x
two  = \f-> \x-> f (f x)
three= \f-> \x-> f (f (f x))

-- this is the successor function
next = \n-> \f-> \x-> f (n f x)

plus = \m-> \n-> \f-> \x-> m f (n f x)

iszero = \n-> n (\x-> false) true

-- The following "num" converts a Church's numeral back into an integer.
--
-- Since every "numeral" is a function that takes two arguments:
-- the first is a function applying to the second argument.
-- (+1) is the increment function. Therefore, 
-- zero (+1) 0 => 0
-- one (+1) 0 => (+1) 0 => 1
-- two (+1) 0 => (+1) ((+1) 0) => (+1) 1 => 2
-- and so on ...
--
num = \n-> n (+1) 0

--Now, try the following:
--
-- num zero
-- num one
-- num two
-- true 1 0
-- false 1 0
-- num (next zero)
-- num (next one)
-- num (next two)
-- plus one one
-- num (plus two two)
-- iszero zero
-- (iszero zero) 1 0
-- (iszero one) 1 0

