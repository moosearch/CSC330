--
-- ints n generates an infinite list of integers starting from n
--
ints n = n : (ints (n+1))

--
-- prefix n l returns the first n elements of list l
--
prefix n l = if n == 0 then []
             else if not (null l) then (head l) : (prefix (n-1) (tail l))
                                  else []

--
-- cancel n l removes from list l all elements divisible by n
--
cancel n l = if (mod (head l) n) == 0
			then cancel n (tail l)
			else (head l): (cancel n (tail l))

--
-- filter1 l keeps the first element of l and then removes all remaining elements of l divisible by the
--      the first element
--
filter1 l = (head l): cancel (head l) (tail l)

prime1 l = (head l) : prime1 (filter1 (tail l))

allprimes = prime1 (ints 2)

primes n = prefix n allprimes 

