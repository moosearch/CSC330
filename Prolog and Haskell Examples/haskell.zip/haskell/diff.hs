diff l1 l2 =
   if l1 == [] then l2
   else if (head l1) == (head l2) then
     diff (tail l1) (tail l2)
   else
     (head l2) : (diff l1 (tail l2))
