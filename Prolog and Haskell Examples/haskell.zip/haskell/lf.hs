-- See
-- http://www.embedded.com/showArticle.jhtml?articleID=196701707&pgno=1
-- for an example of Linear Feedback Shift Registers
--

-- compute the 'XOR' element-by-element on two input lists
--
xor xs ys = if (head xs) == (head ys) then
                0 : (xor (tail xs) (tail ys))
            else
                1 : (xor (tail xs) (tail ys))

--
-- a basic building block for a single cell shift register, which copies
-- its input to its output
--
cell xs = (head xs) : (cell (tail xs))


--
-- expand a triplet of 3 lists into a list of triplets
--
expand3 (xs,ys,zs) =
      ((head xs),(head ys),(head zs)) : 
       (expand3 ((tail xs),(tail ys),(tail zs)))


--
-- compute the first "N" non-cyclic elements of a list, i.e., the
-- first N elements that do not occur in the "prefix".
--
first xs prefix = 
      if xs == [] then 
         prefix
      else if notElem (head xs) prefix then
         first (tail xs) ((head xs) : prefix)
      else
         prefix

--
-- display a table of non-cyclic values of a linear feedback shift register
--
table lfsr = reverse (first lfsr [])


--
-- Examples of linear feedback shift registers
--
e1 = let q0 = cell (0 : s0);
         q1 = cell (0 : q0);
         q2 = cell (1 : q1);
         s0 = xor q0 q2
     in expand3 (q0,q1,q2)
        

e2 = let q0 = cell (0 : s0);
         q1 = cell (0 : q0);
         q2 = cell (1 : q1);
         s0 = xor q1 q2
     in expand3 (q0,q1,q2)
