--
-- A classic recursive "factorial" function in Haskell
--
fac 0 = 1
fac n = n * fac (n-1)

--
-- Church's numerals "2"
--
twice = \f -> \x -> f (f x)

--
--The successor function
--
inc = (+) 1

--
-- Try:
--
-- fac 10
-- fac 50
-- fac (inc 5)
-- twice inc
-- twice inc 0
-- twice twice
-- twice twice fac
-- twice twice fac 3
-- twice twice twice inc 0

