s = \x -> \y -> \z -> x z (y z)

k = \x -> \y -> x

i = \x -> x
