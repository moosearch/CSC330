// MHMC (UVic/CS 16/Mar/2003)

#include <stdio.h>

//=====================================
//   S Y M B O L      T A B L E
//=====================================
//  Our symbol table is organized as follows:
//
//  <len0><symbol0>'\0' <len1><symbol1>'\0' ...
//
// Every entry consists of a length byte and a symbol, followed by a '\0'.
// Every symbol is unique. When a new symbol is added, we must search
// the symbol table to determine whether it already exists.
// Identical symbols have an indentical index value.
// 
#define MAX_TABLE 	10000   // size of symbol table


  // symbol table state
static char symbol_table[MAX_TABLE];
static int  index = 0;   // next unused index into "symbol_table"


  // put the current symbol away and return an index to it
  // identical symbols have the same index value
static int add_symbol( char sym[], int length ) {

    int i, idx, l;

      // first, look it up; if found, don't store it
    i = 0; 
    while( i < index ) {
        l = (int) symbol_table[i];
	if ((l == length) && 
            (strncmp( sym, &(symbol_table[i+1]), length) == 0))
	    return i;   // found it
	  // next symbol, skip the length and '\0' bytes
	i = i + l + 2;
    }

      // now, we can store it
    if ((index+length+2) > MAX_TABLE) {
        printf( "ERROR: exceed symbol table size!\n" );
	exit( -1 );
    }

    idx = index;
        // store its "length" as the first character of this new symbol
    symbol_table[index++] = (char) length;
        // copy the symbol from "buf" into symbol_table, including '\0'
    for( i=0; i <= length; ++i ) {
        symbol_table[index++] = sym[i];
    }
    return idx;

} // add_symbol


static char *string_of( int id ) {

    return &(symbol_table[id+1]);

} // string_of



  // for debugging purpose only
static void show_symbols() {

    int i, length;

    i = 0;
    while( i < index ) {
        length = (int) symbol_table[i];
	printf( "%d : %s, %d\n", i, string_of(i), length );
	i = i + length + 2;
    }

} // show_symbols


//==================================
//  C E L L    S T O R A G E
//==================================
#define MAX_CELLS	10000

  // cell types
#define FREE	100
#define	CONS	101
#define	CNUM	102
#define	CSYM	103
#define NILL    104

#define UNDEF   -1

struct cell {
	int	type;   // CONS, CNUM, CSYM, FREE
	int	head;   // number value, symbol value, pointer to a cell
	int	tail;
};

static struct cell	cells[MAX_CELLS];  // cell storage
static int  nil = UNDEF;   // the universal "NIL"
static int  free = UNDEF;  // head of a list of free cells


   // allocate a new cell of 'type'
static int new_cell( int type ) {

    int  c;

    if (free == UNDEF) {
        printf( "Exhausted cell storage!\n" );
	exit( -1 );
    }

    c = free;
    free = cells[free].tail;

    cells[c].type = type;
    cells[c].tail = UNDEF;

    return c;

} // new_cell



  // return the cell/cells referenced by "c" back into our free list
static void free_cell( int c ) {

    if ( (c == UNDEF) || (c == nil) ) return;

    switch( cells[c].type ) {
	case CNUM:
	case CSYM:
	    cells[c].type = FREE;
	    cells[c].tail = free;
	    free = c;
	    break;
	case CONS:
	    free_cell( cells[c].head );
	    free_cell( cells[c].tail );
	    break;
    }
   
} // free_cell



   // initialize the cells as a "free" linked list
static void init_cells(void) {

    int i;

    for( i=0; i < (MAX_CELLS-1); ++i ) {
        cells[i].type = FREE;
	cells[i].tail = i+1;
    }
    cells[MAX_CELLS-1].type = FREE;
    cells[MAX_CELLS-1].tail = UNDEF;
    free = 0;

      // initialize a universal "NIL" list
    nil = new_cell(NILL);
    cells[nil].head = add_symbol( "NIL", 3 );
    cells[nil].tail = nil;

} // init_cells

static void print_exp( int exp );

static void type_error( int exp, int type ) {

    printf( "\nType error: '" );
    print_exp( exp ); 
    printf( "' is not a " );
    switch ( type ) {
	case NILL: printf( "()" ); break;
	case CSYM: printf( "symbol" ); break;
	case CNUM: printf( "number" ); break;
	case CONS: printf( "cons" ); break;
    }
    putchar( '\n' );

}  // type_error


  // return the head of "exp"
static int car( int exp ) {

    if (cells[exp].type == CONS) {
	return cells[exp].head;
    } else
	type_error( exp, CONS );

} // car


  // return the tail of "exp"
static int cdr( int exp ) {

    if (cells[exp].type == CONS) {
	return cells[exp].tail;
    } else 
	type_error( exp, CONS );

} // cdr


static int make_cons( int hd, int tl ) {

    int ret;

    ret = new_cell( CONS );
    cells[ret].head = hd;
    cells[ret].tail = tl;
    return ret;

} // make_cons


static int make_number( int val ) {

    int ret;

    ret = new_cell( CNUM );
    cells[ret].head = val;
    return ret;

} // make_number


static int make_symbol( int sym ) {

    int ret;

    ret = new_cell( CSYM );
    cells[ret].head = sym;
    return ret;

} // make_symbol


  // return the atomic value of "exp"; "exp" must be an atom
static int cell_value_of( int exp ) {

    return cells[exp].head;

} // cell_value_of



static int is_number( int exp ) {

  return (cells[exp].type == CNUM);

} // is_number


static int is_symbol( int exp ) {

  return (cells[exp].type == CSYM);

} // is_symbol


static int is_cons( int exp ) {

  return (cells[exp].type == CONS);

} // is_cons


static int is_nil( int exp ) {

    return (cells[exp].type == NILL);

} // is_nil


static int is_atom( int exp ) {

  return (is_number(exp) || is_symbol(exp) || is_nil(exp));

} // is_atom


//==================================
//  P R E T T Y    P R I N T I N G
//==================================


  // "exp" must be a "cons" pair
static void print_list( int exp ) {

    putchar( '(' );
    print_exp( car(exp) );
    exp = cdr(exp);
    while( is_cons(exp) ) {
	putchar( ' ' );
	print_exp( car(exp) );
	exp = cdr(exp);
    }
    if (!is_nil(exp)) {
	printf( " . " );
	print_exp( exp );
    }
    putchar( ')' );

} // print_list


static void print_exp( int exp ) {

    if (is_nil(exp) )
        printf( "()" );
    else if (is_number(exp))
	printf( "%d", cell_value_of(exp) );
    else if (is_symbol(exp))
	printf( "%s", string_of(cell_value_of(exp)) );
    else if (is_cons(exp))
	print_list( exp );
   
} // print_exp



//=====================================
//   L E X I C A L     A N A L Y Z E R
//=====================================

#define	MAX_LINE	1024	// size of input line buffer
#define	BUF_LEN 	128	// size of input token buffer

  // token types
#define EOI	0	// end of input
#define	LP	1	// '('
#define RP	2	// ')'
#define DOT	3	// '.'
#define NUM	4	// <number>
#define SYM	5	// <symbol>
#define MT	66	// <empty>
#define ERR     99	// error

  // lexical analyzer and parser states
static char	line[MAX_LINE];
static int	llen;   // length of the current input line
static int	in;     // index into line
static int	ch;     // next input character
static char 	buf[BUF_LEN];
static int  	tlen;	// next token length
static int  	token;	// next input token type

static int	nesting;  // number of nested parentheses


  // read a line into "line" 
static void read_line() {

    char c;
    int  i;

    printf( "[%d] ", nesting );
    in = 0;
    i = 0;
    do {
	c = getchar();
	line[i++] = c;
    } while( (c != EOF) && (c != '\n') && (i < MAX_LINE) );

    if ( i == MAX_LINE ) {
	printf( "Exception : input line too long!\n" );
	exit( -1 );
    }
    llen = i;

} // read_line


static int is_space( int c ) {

    return ((c == ' ') || (c == '\n'));

} // is_space



static void next_ch() {

    if (in == llen) read_line();
    ch = line[in++];

} // next_ch



static void unget_ch() {

    if (in > 0) --in;

} // unget_ch



static int is_digit( int c ) {

    return ((c >= '0') && (c <= '9'));

} // is_digit



static int is_letter( int c ) {

    return ((c >= 'a') && (c <= 'z')) ||
           ((c >= 'A') && (c <= 'Z'));

} // is_letter



  // scan until a recognized token is encountered; skip all white spaces
static void next_token() {

    if ((token == EOI) || (token == ERR)) return;

    // skip all white spaces
    do {
	next_ch(); 
	if (ch == EOF) break;
    } while (is_space(ch));

    if (ch == EOF) { token = EOI; return;}

    tlen = 0;
    switch( ch ) {
	case '(': token = LP;  break;
	case ')': token = RP;  break;
	case '.': token = DOT; break;
	case '\'': token = SYM; break;
	default: // <number> or <symbol>
	    if (is_digit(ch)) {
		while( is_digit(ch) ) {  // <number>
		   buf[tlen++] = ch;
		   next_ch();
		   if (tlen == BUF_LEN ) {
			printf( "Syntax error: number too big at '%c'!\n", ch );
			token = ERR;
			return;
		   }
		}
		unget_ch();
		buf[tlen] = '\0';
		token = NUM;
		// printf( "Number : %s, %d\n", buf, tlen );
	    } else if (is_letter(ch)) {  // <symbol>
		while( is_digit(ch) || is_letter(ch) ) {
		   buf[tlen++] = ch;
		   next_ch();
		   if (tlen == BUF_LEN ) {
			printf( "Syntax error: symbol too big at '%c'!\n", ch );
			token = ERR;
			return;
		   }
		}
		unget_ch();
		buf[tlen] = '\0';
		token = SYM;
		// printf( "Symbol : %s, %d\n", buf, tlen );
	    } else {
		token = ERR;
		printf( "Syntax error: at '%c'!\n", ch );
	    }
	    return;
    }
    buf[tlen++] = ch; 
    buf[tlen] = '\0'; 

} // next


//=======================
//   P A R S E R
//=======================

  // the next token must be of "type"
static void accept( int type ) {

    if (token == type) {
	  // don't read a new token when at the top level
        if (nesting == 0) 
	    token = MT;
	else
	    next_token();
    } else 
        token = ERR;

} // accept


static void s_exp( int *exp );

  //  <s-exps>::= <empty> | <s-exp> ( '.' <s-exp> | <s-exps> )
static void s_exps( int *exps ) {

    int car = UNDEF;
    int cdr = UNDEF;

	// test for First(s-exp)
    if ((token == NUM) || (token == SYM) || (token == LP)) {
        s_exp( &car );
	if (car == UNDEF) return;
        if (token == DOT) {
	    accept( DOT );
	    s_exp( &cdr );
        } else {
	    s_exps( &cdr );
	}
	if (cdr == UNDEF) {
	   *exps = make_cons( car, nil );
	} else {
	   *exps = make_cons( car, cdr );
        }
    }

} // s_exps



  //  <s-exp> ::= <number>  | <symbol> | '(' <s-exps> ')'  
static void s_exp(int *exp ) {

    int exps = UNDEF;

    if (token == NUM) {
	*exp = make_number( atoi(buf) );
	accept( NUM );
    } else if (token == SYM) {
	*exp = make_symbol( add_symbol( buf, tlen ) );
	accept( SYM );
    } else {
        ++nesting;
	accept( LP ); 
	s_exps( &exps );
	--nesting;
	accept( RP ); 
	if (exps == UNDEF) // <s_exps> is <empty>
	   *exp = nil; 
	else
	   *exp = exps;
    }

} // s_exp


//===========================
//   E V A L U A T O R
//===========================

// builtin operators
static int add;
static int sub;
static int mul;
static int div;
static int mod;
static int cons;
static int hd;
static int tl;
static int quote;


static int is_unary( int exp ) {

    return ((is_cons(cdr(exp))) && is_nil(cdr(cdr(exp))));

} // is_unary


static int is_binary( int exp ) {

    return ((is_cons(cdr(exp))) &&
            (is_cons(cdr(cdr(exp)))) &&
            (is_nil(cdr(cdr(cdr(exp))))) );

} // is_binary


  // return 1 if there exists a cell value "cval" of "exp"
static int eval( int exp, int *cval ) {

    int ret, lc, rc;      // cells
    int op, lv, rv, val;  // values

      // return the value of an atomic expression
    if (is_atom(exp)) {
	*cval = exp;
        return 1;
     }

      // "exp" must be a "cons" pair
    if (!is_symbol(car(exp))) {
	printf( "\nError: illegal operator!\n" );
	return 0;
    }
    op = cell_value_of(car(exp));
    if (op == quote) {
           // 'exp' must be a unary expression
	if(!is_unary(exp)) {
	    printf( "\nError: non unary expression!\n" );
	    return 0;
	}
	   // don't evaluate the argument of quote
        *cval = car(cdr(exp));
    } else if ((op == hd) || (op == tl)) {
           // 'exp' must be a unary expression
        if (!is_unary(exp)) {
	    printf( "\nError: non unary expression!\n" );
	    return 0;
	}
           // 'exp' must be a "cons" pair
        if ((!eval(car(cdr(exp)), &lc)) ||
	    (!is_cons( lc ))) {
	    printf( "\nError: " );
	    print_exp( exp );
	    printf( " does not evaluate to a cons pair!\n" );
	    return 0;
	}
	if (op == hd) {
	    *cval = car(lc);
	} else { // (op == tl)
	    *cval = cdr(lc);
	}
    } else if (op == cons) {
           // 'exp' must be a 2-argument expression
        if (!is_binary(exp)) {
	    printf( "\nError: non binary expression!\n" );
            return 0;
	}
        if ((!eval(car(cdr(exp)), &lc )) ||
            (!eval(car(cdr(cdr(exp))), &rc))) return 0;
        *cval = make_cons( lc, rc );
    } else if ((op == add) || (op == sub) || (op == mul) ||
	       (op == div) || (op == mod)) {
          // 'exp' must be a 2-argument numeric expression
        if (!is_binary(exp)) {
	    printf( "\nError: non binary expression!\n" );
            return 0;
	}
          // the arguments must be of integer values
        if ( (!eval(car(cdr(exp)), &lc)) || (!is_number(lc)) ||
             (!eval(car(cdr(cdr(exp))), &rc)) || (!is_number(rc)) ) {
	    printf( "\nError: arguments do not evaluate to numbers!\n" );
	    return 0;
	}

        lv = cell_value_of(lc);
        rv = cell_value_of(rc);
        if (op == add) 
	    val = lv + rv;
        else if (op == sub)
	    val = lv - rv;
        else if (op == mul)
	    val = lv * rv;
        else if (op == div)
	    val = lv / rv;
        else // (op == mod)
	    val = lv % rv;
        *cval = make_number( val );
    } else {
	printf( "\nError: unknown operator '%s'\n", string_of(op) );
	return 0;
    }
    return 1;

} // eval


//=====================================
//   M A I N
//=====================================


main() {

    int exp, cval;  // cells

    in = 0;
    llen = 0;
    ch = '\n';
    token = MT;

    init_cells();

    add = add_symbol( "add", 3 );
    sub = add_symbol( "sub", 3 );
    mul = add_symbol( "mul", 3 );
    div = add_symbol( "div", 3 );
    mod = add_symbol( "mod", 3 );
    cons = add_symbol( "cons", 4 );
    hd = add_symbol( "hd", 2 );
    tl = add_symbol( "tl", 2 );
    quote = add_symbol( "'", 1 );

    nesting = 0;

    printf( "An S-expression Evaluator.\n" );
    next_token();
    while (token != EOI) {
	exp = UNDEF;
	s_exp( &exp );
	if ( (token != ERR) && (exp != UNDEF) ) {
	    print_exp( exp ); 
	    if (eval( exp, &cval )) {
	        printf( " ==> " );
	        print_exp( cval );
	        putchar( '\n' );
	    } else
		token = ERR;
	    free_cell( exp );
	}
	if (token == ERR) { 
           read_line(); 
	   token = MT;
	}
        if (token == MT) next_token();
    }

    // show_symbols();
    printf( "\nEnd.\n" );
  
} // main
