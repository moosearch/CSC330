%
% concat( Xs, Ys, Zs ) if Zs is the concatenation of lists Xs and Ys
%
concat( [], Ys, Ys ).
concat( [X|Xs], Ys, [X|Zs] ) :- concat( Xs, Ys, Zs ).

rev( [], [] ).
rev( [U|Xs], Ys ) :-
   rev( Xs, Zs ), concat( Zs, [U], Ys ).

%
% nonmember( X, Ys ) if X is not a member of list Ys
%
nonmember( X, [] ).
nonmember( X, [Y|Ys] ) :- X \= Y, nonmember( X, Ys ).

%
% len( L, N ) if N is the length of list L
%
len( [], 0 ).
len( [_|Xs], N ) :- len( Xs, N1 ), N is N1 + 1.


aprefix( P, L ) :- concat( P, S, L ).

asuffix( S, L ) :- concat( P, S, L ).

member1( X, L ) :- concat( P, [X|S], L ).

%
% sublist( S, L ) if S is a sublist of L
%
asublist( A, ABC ) :- concat( AB, C, ABC ), concat( A, B, AB ).

%
% remove( X, L, D ) if D is the list after removing X from L
%
remove( X, L, D ) :-
    concat( P, [X|S], L ), concat( P, S, D ).


perm( [], [] ).
perm( Xs, Ys ) :- 
    remove( X, Xs, Xs1 ), perm( Xs1, Xs2 ), concat( [X], Xs2, Ys ).


ordered( [] ).
ordered( [X] ).
ordered( [X,Y|Ys] ) :- X =< Y, ordered( [Y|Ys] ).

sort( L, M ) :- perm( L, M ), ordered( M ).
