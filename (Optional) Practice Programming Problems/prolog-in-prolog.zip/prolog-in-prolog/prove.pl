%
% prove(G) is true if G is provable.
%
prove(true).
prove((G,Gs)) :-
    prove(G), prove(Gs).
prove(H) :-
    clause(H,B), prove(B).
