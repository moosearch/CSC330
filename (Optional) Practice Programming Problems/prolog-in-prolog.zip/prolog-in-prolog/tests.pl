:- include('parent.pl').
:- include('prove.pl').
:- include('graph.pl').

test1 :-
  prove(ancestor(X,Y),T), explain(T).

test2(P) :-
   path(a,e,P).
